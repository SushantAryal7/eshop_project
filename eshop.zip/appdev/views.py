from django.shortcuts import render, redirect, HttpResponseRedirect
from django.views import View
from .models import Brand, Index, Customer, Order
from appdev.middlewares.auth import simple_middleware


# Create your views here.

def index(request):
    if request.method == 'POST':
        product_id = request.POST.get('product_id')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product_id)
            if quantity:
                if remove:
                    if quantity <= 1:
                        cart.pop(product_id)
                    else:
                        cart[product_id] = quantity - 1
                else:
                    cart[product_id] = quantity + 1
            else:
                cart[product_id] = 1

        else:
            cart = {}
            cart[product_id] = 1
        request.session['cart'] = cart
        print(cart)

        return redirect('index')

    else:
        cart = request.session.get('cart')
        if not cart:
            request.session['cart'] = {}
        products = None
        brands = Brand.objects.all()
        brand_id = request.GET.get('brand_id')
        if brand_id:
            products = Index.objects.filter(brand_id=brand_id)
        else:
            products = Index.objects.all()
        context = {'products': products,
                   'brands': brands
                   }

        print(request.session.get('email'))
        return render(request, 'index.html', context)


class Login(View):
    returnurl = None

    def get(self, request):
        Login.returnurl = request.GET.get('returnurl')
        return render(request, 'login.html')

    def post(self, request):
        first = request.POST['first']
        last = request.POST['last']
        email = request.POST['email']
        password = request.POST['password']
        customer = Customer(first=first, last=last, email=email, password=password)
        customer.save()
        request.session['customer'] = customer.id
        request.session['email'] = customer.email

        if Login.returnurl:
            return HttpResponseRedirect(Login.returnurl)
        else:
            Login.returnurl = None
            return redirect('index')

        return redirect('index')


"""def login(request):
    returnurl = None
    if request.method == 'POST':
        first = request.POST['first']
        last = request.POST['last']
        email = request.POST['email']
        password = request.POST['password']
        customer = Customer(first=first, last=last, email=email, password=password)
        customer.save()
        request.session['customer'] = customer.id
        request.session['email'] = customer.email
        if returnurl:
            pass
        else:
            returnurl = None
            return redirect('index')
        return redirect('index')

    elif request.method == 'GET':
        returnurl = request.GET.get('returnurl')
        return render(request, 'login.html')
    else:
        return render(request, 'login.html')"""


def signup(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        customer = Customer.objects.get(email=email)
        if customer:
            if customer.password == password:
                request.session['customer'] = customer.id
                request.session['email'] = customer.email
                print(request.session['customer'])
                return redirect('index')
            else:
                return render(request, 'signup.html')
        else:
            return render(request, 'signup.html')
    else:
        return render(request, 'signup.html')


def logout(request):
    request.session.clear()
    return redirect('signup')


@simple_middleware
def cart(request):
    ids = list(request.session.get('cart').keys())
    products = Index.objects.filter(id__in=ids)
    print(list(request.session.get('cart').keys()))
    print(products)

    return render(request, 'cart.html', {'products': products})


def checkout(request):
    if request.method == 'POST':
        address = request.POST.get('address')
        mobile = request.POST.get('mobile')
        customer = request.session.get('customer')
        cart = request.session.get('cart')
        pproduct = list(cart.keys())
        product = Index.objects.filter(id__in=pproduct)
        for products in product:
            order = Order(products=products,
                          customer=Customer(id=customer),
                          address=address,
                          price=products.price,
                          mobile=mobile,
                          quantity=cart.get(str(products.id))
                          )
            order.save()
        request.session['cart'] = {}
        print(address)
        return redirect('cart')

    else:
        return redirect('cart')


@simple_middleware
def order(request):
    customer = request.session.get('customer')
    orderr = Order.objects.filter(customer=customer)
    orders = orderr[::-1]
    print(orderr)
    return render(request, 'order.html', {'orders': orders})


''' remove = request.POST['product_IID']
        product_id = request.POST['product_id']
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product_id)
            if quantity:
                cart[product_id] = quantity+1
            else:
                cart[product_id] = 1


        else:
            cart = {}
            cart[product_id] = 1
        request.session['cart'] = cart
        print(cart)'''
